# lanelet2_traffic_light_node
Uses lanelet2 map to get traffic light position and project into camera frame for  Autoware traffic light detection
